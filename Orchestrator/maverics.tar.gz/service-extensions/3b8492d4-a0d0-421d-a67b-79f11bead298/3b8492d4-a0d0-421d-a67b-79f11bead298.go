package main

import (
	"errors"
	"fmt"
	"net/http"
	"strings"

	"github.com/strata-io/service-extension/orchestrator"
)

// Define the structure for the metadata
type Metadata struct {
	Key   string `json:"key"`
	Value string `json:"value"`
}

// LoadAttrs handles loading attributes dynamically based on IDP metadata
func LoadAttributes(api orchestrator.Orchestrator, rw http.ResponseWriter, req *http.Request) error {
	log := api.Logger()
	session, err := api.Session()
	if err != nil {
		log.Error("Failed to get session: ", err)
		return err
	}

	type User struct {
		sm_user   string `json:"sm_user"`
		firstname string `json:"firstname"`
		lastname  string `json:"lastname"`
		email     string `json:"email"`
		role      string `json:"role"` 
	}

	// Get the list of IDP metadata dynamically
	metadata := api.Metadata()
	rawIDPs, ok := metadata["idps"]
	if !ok {
		return errors.New("idps not configured in metadata")
	}

	idps := strings.Split(rawIDPs.(string), ",")
	for _, i := range idps {
		log.Debug(
			"msg", "idp configured",
			"idp", i,
		)
	}
	for i := 0; i < len(idps); i++ {
		key := fmt.Sprintf("%s.authenticated", idps[i])
		res,_ := session.GetString(key)
		log.Info("load attrsSE", "user is authenticated to "+idps[i]+"; "+res)
		if res == "true" {
			log.Info("msg", "adding idps[i] attributes")
			sm_user, _ := session.GetString(idps[i] + ".name")
			firstname, _ := session.GetString(idps[i] + ".given_name")
			lastname, _ := session.GetString(idps[i] + ".family_name")
			email, _ := session.GetString(idps[i] + ".preferred_username")
			roles, _ := session.GetString("idr.roles")
			session.SetString("generic.sm_user", sm_user)
			log.Info("msg user is", sm_user)
			session.SetString("generic.firstname", firstname)
			session.SetString("generic.lastname", lastname)
			session.SetString("generic.email", email)
			session.SetString("generic.roles", roles)
		}
	}
session.Save()
	// Iterate through the metadata to retrieve attributes
	// for _, data := range metadata {
	// 	usr := User{}

	// 	if err := json.Unmarshal([]byte(data.Val), &usr); err != nil {
	// 		log.Error("Failed to unmarshal attributes: ", err)
	// 		continue
	// 	}

	// 	// Set the attributes in the session
	// 	session.SetString("sm_user", attributes.SmUser)
	// 	session.SetString("firstname", attributes.Firstname)
	// 	session.SetString("lastname", attributes.Lastname)
	// 	session.SetString("email", attributes.Email)

	// 	log.Info("Attributes set in session for user: ", attributes.SmUser)
	// }

	return nil
}